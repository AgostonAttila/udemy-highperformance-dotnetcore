# High Performance coding in .NET - Workshop
Slides and sample code for the "High Performance Coding in .NET" workshop. - HTL Leonding 1.3.2018

More info: [in the announcement pdf](PerformanceMonitoringPoster.pdf)


