﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimlpeSampleStockAppModel
{
    public class StockIndexData
    {
        public String Symbol { get; set; }

        public String Name { get; set; }
    }
}
