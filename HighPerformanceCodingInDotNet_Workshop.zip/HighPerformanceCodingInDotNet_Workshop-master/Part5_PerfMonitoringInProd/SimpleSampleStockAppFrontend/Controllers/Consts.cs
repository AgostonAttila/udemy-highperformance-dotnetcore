﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleSampleStockAppFrontend.Controllers
{
    public static class Consts
    {
        public static String SERVICESURL => "http://simplesamplestockappservices20180228035447.azurewebsites.net/api/";
    }
}
