﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SimpleSampleStockAppFrontend.Controllers
{
    public static class Consts
    {
        public static String SERVICESURL => "http://localhost:53275/api/";
    }
}
